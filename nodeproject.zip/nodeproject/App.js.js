const express = require('express');
const http = require('http');
var mysql=require('mysql2');
var url = require("url");
const bcrypt = require('bcrypt');
const path = require("path");
const bodyParser = require('body-parser');
const users = require('./data').userDB;
const app = express();
const server = http.createServer(app);

app.use(bodyParser.urlencoded({extended: false}));
app.use(express.static(path.join(__dirname,'./public')));


app.get('/',(req,res) => {
    res.sendFile(path.join(__dirname,'./public/index.html'));
});


app.post('/register', async (req, res) => {
    try{
        let foundUser = users.find((data) => req.body.email === data.email);
        if (!foundUser) {
    
            let hashPassword = await bcrypt.hash(req.body.password, 10);
    
            let newUser = {
                id: Date.now(),
                username: req.body.username,
                email: req.body.email,
                password: hashPassword,
            };
            users.push(newUser);
            console.log('User list', users);
			//Data bse code start
			var nam=req.body.username;
			var ema=req.body.email;
    var con=mysql.createConnection({host:"localhost",user:"root",password:"root",database:"demo"});
con.connect(function(err)
{
if(err) throw err;
console.log("connected");
con.query("insert into stu values('"+nam+"','"+ema+"')",function(err,result)
{
if(err) throw err;
console.log("Database created");

});
});
//data base code end
            res.send("<div align ='center'><h2>Registration successful</h2></div><br><br><div align='center'><a href='./login.html'>login</a></div><br><br><div align='center'><a href='./registration.html'>Register another user</a></div>");
        } else {
            res.send("<div align ='center'><h2>Email already used</h2></div><br><br><div align='center'><a href='./registration.html'>Register again</a></div>");
        }
    } catch{
        res.send("Internal server error");
    }
});

app.post('/login', async (req, res) => {
    try{
        let foundUser = users.find((data) => req.body.email === data.email);
        if (foundUser) {
    
            let submittedPass = req.body.password; 
            let storedPass = foundUser.password; 
    
            const passwordMatch = await bcrypt.compare(submittedPass, storedPass);
            if (passwordMatch) {
                let usrname = foundUser.username;
                res.send("<div align ='center'><h2>login successful</h2></div><br><br><br><div align ='center'><h3>Hello ${usrname}</h3></div><br><br><div align='center'><a href='./login.html'>logout</a></div>");
            } else {
                res.send("<div align ='center'><h2>Invalid email or password</h2></div><br><br><div align ='center'><a href='./login.html'>login again</a></div>");
            }
        }
        else {
    
            let fakePass = $2b$$10$ifgfgfgfgfgfgfggfgfgfggggfgfgfga;
            await bcrypt.compare(req.body.password, fakePass);
    
            res.send("<div align ='center'><h2>Invalid email or password</h2></div><br><br><div align='center'><a href='./login.html'>login again<a><div>");
        }
    } catch{
        res.send("Internal server error");
    }
});

app.post('/patientlogindata', async (req, res) => {
    try{
        let foundUser = users.find((data) => req.body.d1 === data.email);
        if (!foundUser) {
    
            let hashPassword = await bcrypt.hash(req.body.d1, 10);
    
            let newUser = {
                id: Date.now(),
                username: req.body.d1,
                email: req.body.d2,
                password: hashPassword,
            };
            users.push(newUser);
            console.log('User list', users);
			//Data bse code start
			var a=req.body.d1;
			var b=req.body.d2;
    var con=mysql.createConnection({host:"localhost",user:"root",password:"root",database:"pharmacyproject"});
con.connect(function(err)
{
if(err) throw err;
console.log("connected");
con.query(" insert into  login(userid,password) values('"+a+"','"+b+"')",function(err,result)
{
if(err) throw err;
console.log("Database created");

});
});
//data base code end
            res.send("<div align ='center'><h2>Registration successful</h2></div><br><br><div align='center'><a href='./login.html'>login</a></div><br><br><div align='center'><a href='./registration.html'>Register another user</a></div>");
        } else {
            res.send("<div align ='center'><h2>Email already used</h2></div><br><br><div align='center'><a href='./DoctorMedicinePrescriptionForm.html'>Enter Again</a></div>");
        }
    } catch{
        res.send("Internal server error");
    }
});





app.post('/adminlogindata', async (req, res) => {
    try{
        let foundUser = users.find((data) => req.body.d1 === data.email);
        if (!foundUser) {
    
            let hashPassword = await bcrypt.hash(req.body.d1, 10);
    
            let newUser = {
                id: Date.now(),
                username: req.body.d1,
                email: req.body.d2,
                password: hashPassword,
            };
            users.push(newUser);
            console.log('User list', users);
			//Data bse code start
			var a=req.body.d1;
			var b=req.body.d2;

        
    var con=mysql.createConnection({host:"localhost",user:"root",password:"root",database:"pharmacyproject"});
con.connect(function(err)
{
if(err) throw err;
console.log("connected");
con.query(" insert into  adminlogin(user_id,password) values('"+a+"','"+b+"')",function(err,result)
{
if(err) throw err;
console.log("Database created");

});
});
//data base code end
            res.send("<div align ='center'><h2>Registration successful</h2></div><br><br><div align='center'><a href='./login.html'>login</a></div><br><br><div align='center'><a href='./registration.html'>Register another user</a></div>");
        } else {
            res.send("<div align ='center'><h2>Email already used</h2></div><br><br><div align='center'><a href='./DoctorMedicinePrescriptionForm.html'>Enter Again</a></div>");
        }
    } catch{
        res.send("Internal server error");
    }
});

app.post('/createaccountdata', async (req, res) => {
    try{
        let foundUser = users.find((data) => req.body.d1 === data.email);
        if (!foundUser) {
    
            let hashPassword = await bcrypt.hash(req.body.d1, 10);
    
            let newUser = {
                id: Date.now(),
                username: req.body.d1,
                email: req.body.d2,
                password: hashPassword,
            };
            users.push(newUser);
            console.log('User list', users);
			//Data bse code start
			var a=req.body.d1;
			var b=req.body.d2;
            var c=req.body.d3;
			var d=req.body.d4;
            var e=req.body.d5;
			var f=req.body.d6;
            var g=req.body.d7;
			var h=req.body.d8;
        
    var con=mysql.createConnection({host:"localhost",user:"root",password:"root",database:"pharmacyproject"});
con.connect(function(err)
{
if(err) throw err;
console.log("connected");
con.query(" insert into  newaccount(firstnam,secondnam,gender, email,DOB,bldgrp,password,reentrpass) values('"+a+"','"+b+"','"+c+"','"+d+"','"+e+"','"+f+"','"+g+"','"+h+"')",function(err,result)
{
if(err) throw err;
console.log("Database created");

});
});
//data base code end
            res.send("<div align ='center'><h2>Registration successful</h2></div><br><br><div align='center'><a href='./login.html'>login</a></div><br><br><div align='center'><a href='./registration.html'>Register another user</a></div>");
        } else {
            res.send("<div align ='center'><h2>Email already used</h2></div><br><br><div align='center'><a href='./DoctorMedicinePrescriptionForm.html'>Enter Again</a></div>");
        }
    } catch{
        res.send("Internal server error");
    }
});













app.post('/doctormedicineprescriptiondata', async (req, res) => {
    try{
        let foundUser = users.find((data) => req.body.d1 === data.email);
        if (!foundUser) {
    
            let hashPassword = await bcrypt.hash(req.body.d1, 10);
    
            let newUser = {
                id: Date.now(),
                username: req.body.d1,
                email: req.body.d2,
                password: hashPassword,
            };
            users.push(newUser);
            console.log('User list', users);
			//Data bse code start
			var a=req.body.d1;
			var b=req.body.d2;
            var c=req.body.d3;
			var d=req.body.d4;
            var e=req.body.d5;
			var f=req.body.d6;
            var g=req.body.d7;
			var h=req.body.d8;
            var i=req.body.d9;
			var j=req.body.d10;
            var k=req.body.d11;
			var l=req.body.d12;
            var m=req.body.d13;
			var n=req.body.d14;
            var o=req.body.d15;
    var con=mysql.createConnection({host:"localhost",user:"root",password:"root",database:"pharmacyproject"});
con.connect(function(err)
{
if(err) throw err;
console.log("connected");
con.query(" insert into  medicineprescription(doc_name,doc_cont,age ,diseases,symptoms,duration_start ,duration_end,bef_breakfast,aft_breakfast ,bef_lunch ,aft_lunch,bef_dinner,aft_dinner,dont,trasction_id) values('"+a+"','"+b+"','"+c+"','"+d+"','"+e+"','"+f+"','"+g+"','"+h+"','"+i+"','"+j+"','"+k+"','"+l+"','"+m+"','"+n+"','"+o+"')",function(err,result)
{
if(err) throw err;
console.log("Database created");

});
});
//data base code end
            res.send("<div align ='center'><h2>Registration successful</h2></div><br><br><div align='center'><a href='./login.html'>login</a></div><br><br><div align='center'><a href='./registration.html'>Register another user</a></div>");
        } else {
            res.send("<div align ='center'><h2>Email already used</h2></div><br><br><div align='center'><a href='./DoctorMedicinePrescriptionForm.html'>Enter Again</a></div>");
        }
    } catch{
        res.send("Internal server error");
    }
});


app.post('/doctormedicineprescriptiondataupdt', async (req, res) => {
    try{
        let foundUser = users.find((data) => req.body.d1 === data.email);
        if (!foundUser) {
    
            let hashPassword = await bcrypt.hash(req.body.d1, 10);
    
            let newUser = {
                id: Date.now(),
                username: req.body.d1,
                email: req.body.d2,
                password: hashPassword,
            };
            users.push(newUser);
            console.log('User list', users);
			//Data bse code start
			var a=req.body.d1;
			var b=req.body.d2;
            var c=req.body.d3;
			var d=req.body.d4;
            var e=req.body.d5;
			var f=req.body.d6;
            var g=req.body.d7;
			var h=req.body.d8;
            var i=req.body.d9;
			var j=req.body.d10;
            var k=req.body.d11;
			var l=req.body.d12;
            var m=req.body.d13;
			var n=req.body.d14;
            var o=req.body.d15;
    var con=mysql.createConnection({host:"localhost",user:"root",password:"root",database:"pharmacyproject"});
con.connect(function(err)
{
if(err) throw err;
console.log("connected");
con.query("update  medicineprescription set doc_name='"+a+"',doc_cont='"+b+"',age='"+c+"' ,diseases='"+d+"',symptoms='"+e+"',duration_start='"+f+"' ,duration_end='"+g+"',bef_breakfast='"+h+"',aft_breakfast='"+i+"' ,bef_lunch='"+j+"' ,aft_lunch='"+k+"',bef_dinner='"+l+"',aft_dinner='"+m+"',dont='"+n+"' where trasction_id='"+o+"'" ,function(err,result)
{
if(err) throw err;
console.log("Database created");

});
});
//data base code end
            res.send("<div align ='center'><h2>Registration successful</h2></div><br><br><div align='center'><a href='./login.html'>login</a></div><br><br><div align='center'><a href='./registration.html'>Register another user</a></div>");
        } else {
            res.send("<div align ='center'><h2>Email already used</h2></div><br><br><div align='center'><a href='./DoctorMedicinePrescriptionForm.html'>Enter Again</a></div>");
        }
    } catch{
        res.send("Internal server error");
    }
});










app.post('/patientregistrationdata', async (req, res) => {
    try{
        let foundUser = users.find((data) => req.body.d1 === data.email);
        if (!foundUser) {
    
            let hashPassword = await bcrypt.hash(req.body.d1, 10);
    
            let newUser = {
                id: Date.now(),
                username: req.body.d1,
                email: req.body.d2,
                password: hashPassword,
            };
            users.push(newUser);
            console.log('User list', users);
			//Data bse code start
			var a=req.body.d1;
			var b=req.body.d2;
            var c=req.body.d3;
			var d=req.body.d4;
            var e=req.body.d5;
			var f=req.body.d6;
            var g=req.body.d7;
			var h=req.body.d8;
            var i=req.body.d9;
            var j=req.body.d10;
		
    var con=mysql.createConnection({host:"localhost",user:"root",password:"root",database:"pharmacyproject"});
con.connect(function(err)
{
if(err) throw err;
console.log("connected");
con.query(" insert into  patientregistration(patient_name,father_name,gender,mobileno,DOB,bloodgrp,marital_status,patient_address,Email,transaction_id) values('"+a+"','"+b+"','"+c+"','"+d+"','"+e+"','"+f+"','"+g+"','"+h+"','"+i+"','"+j+"')",function(err,result)
{
if(err) throw err;
console.log("Database created");

});
});
//data base code end
            res.send("<div align ='center'><h2>Registration successful</h2></div><br><br><div align='center'><a href='./login.html'>login</a></div><br><br><div align='center'><a href='./registration.html'>Register another user</a></div>");
        } else {
            res.send("<div align ='center'><h2>Email already used</h2></div><br><br><div align='center'><a href='./PatientRegistrationForm.html'>Enter Again</a></div>");
        }
    } catch{
        res.send("Internal server error");
    }
});


app.post('/patientregistrationdataupdate', async (req, res) => {
    try{
        let foundUser = users.find((data) => req.body.d1 === data.email);
        if (!foundUser) {
    
            let hashPassword = await bcrypt.hash(req.body.d1, 10);
    
            let newUser = {
                id: Date.now(),
                username: req.body.d1,
                email: req.body.d2,
                password: hashPassword,
            };
            users.push(newUser);
            console.log('User list', users);
			//Data bse code start
			var a=req.body.d1;
			var b=req.body.d2;
            var c=req.body.d3;
			var d=req.body.d4;
            var e=req.body.d5;
			var f=req.body.d6;
            var g=req.body.d7;
			var h=req.body.d8;
            var i=req.body.d9;
            var j=req.body.d10;
    var con=mysql.createConnection({host:"localhost",user:"root",password:"root",database:"pharmacyproject"});
con.connect(function(err)
{
if(err) throw err;
console.log("connected");
con.query(" update  patientregistration set patient_name='"+a+"',father_name='"+b+"',gender='"+c+"',mobileno='"+d+"',DOB='"+e+"',bloodgrp='"+f+"',marital_status='"+g+"',patient_address='"+h+"',Email='"+i+"' where transaction_id='"+j+"'",function(err,result)
{
if(err) throw err;
console.log("Database created");

});
});
//data base code end
            res.send("<div align ='center'><h2>Registration successful</h2></div><br><br><div align='center'><a href='./login.html'>login</a></div><br><br><div align='center'><a href='./registration.html'>Register another user</a></div>");
        } else {
            res.send("<div align ='center'><h2>Email already used</h2></div><br><br><div align='center'><a href='./PatientRegistrationForm.html'>Enter Again</a></div>");
        }
    } catch{
        res.send("Internal server error");
    }
});


app.post('/patientlogindata', async (req, res) => {
    try{
        let foundUser = users.find((data) => req.body.d1 === data.email);
        if (!foundUser) {
    
            let hashPassword = await bcrypt.hash(req.body.d1, 10);
    
            let newUser = {
                id: Date.now(),
                username: req.body.d1,
                email: req.body.d2,
                password: hashPassword,
            };
            users.push(newUser);
            console.log('User list', users);
			//Data bse code start
			var a=req.body.d1;
			var b=req.body.d2;
            // var c=req.body.d3;
			// var d=req.body.d4;
            // var e=req.body.d5;
			// var f=req.body.d6;
            // var g=req.body.d7;
			// var h=req.body.d8;
            // var i=req.body.d9;
            // var j=req.body.d10;
		
    var con=mysql.createConnection({host:"localhost",user:"root",password:"root",database:"pharmacyproject"});
con.connect(function(err)
{
if(err) throw err;
console.log("connected");
con.query(" insert into  patientregistration(patient_name,father_name,gender,mobileno,DOB,bloodgrp,marital_status,patient_address,Email,transaction_id) values('"+a+"','"+b+"','"+c+"','"+d+"','"+e+"','"+f+"','"+g+"','"+h+"','"+i+"','"+j+"')",function(err,result)
{
if(err) throw err;
console.log("Database created");

});
});
//data base code end
            res.send("<div align ='center'><h2>Registration successful</h2></div><br><br><div align='center'><a href='./login.html'>login</a></div><br><br><div align='center'><a href='./registration.html'>Register another user</a></div>");
        } else {
            res.send("<div align ='center'><h2>Email already used</h2></div><br><br><div align='center'><a href='./PatientRegistrationForm.html'>Enter Again</a></div>");
        }
    } catch{
        res.send("Internal server error");
    }
});



















app.post('/doctorregistrationdata', async (req, res) => {
    try{
        let foundUser = users.find((data) => req.body.d1 === data.email);
        if (!foundUser) {
    
            let hashPassword = await bcrypt.hash(req.body.d1, 10);
    
            let newUser = {
                id: Date.now(),
                username: req.body.d1,
                email: req.body.d2,
                password: hashPassword,
            };
            users.push(newUser);
            console.log('User list', users);
			//Data bse code start
			var a=req.body.d1;
			var b=req.body.d2;
            var c=req.body.d3;
			var d=req.body.d4;
            var e=req.body.d5;
			var f=req.body.d6;
            var g=req.body.d7;
			var h=req.body.d8;
            var i=req.body.d9;
			var j=req.body.d10;
            var k=req.body.d11;
			var l=req.body.d12;
            var m=req.body.d13;
		
    var con=mysql.createConnection({host:"localhost",user:"root",password:"root",database:"pharmacyproject"});
con.connect(function(err)
{
if(err) throw err;
console.log("connected");
con.query(" insert into doctorregistration(doc_Id,doc_name,doc_fthrname,moblno,dob,bloodgrp,email,website,address,speciality,department,qualification,academic) values('"+a+"','"+b+"','"+c+"','"+d+"','"+e+"','"+f+"','"+g+"','"+h+"','"+i+"','"+j+"','"+k+"','"+l+"','"+m+"')",function(err,result)
{
if(err) throw err;
console.log("Database created");

});
});
//data base code end
            res.send("<div align ='center'><h2>Registration successful</h2></div><br><br><div align='center'><a href='./login.html'>login</a></div><br><br><div align='center'><a href='./registration.html'>Register another user</a></div>");
        } else {
            res.send("<div align ='center'><h2>Email already used</h2></div><br><br><div align='center'><a href='./PatientRegistrationForm.html'>Enter Again</a></div>");
        }
    } catch{
        res.send("Internal server error");
    }
});




app.post('/doctorregistrationdataUPDATE', async (req, res) => {
    try{
        let foundUser = users.find((data) => req.body.d1 === data.email);
        if (!foundUser) {
    
            let hashPassword = await bcrypt.hash(req.body.d1, 10);
    
            let newUser = {
                id: Date.now(),
                username: req.body.d1,
                email: req.body.d2,
                password: hashPassword,
            };
            users.push(newUser);
            console.log('User list', users);
			//Data bse code start
			var a=req.body.d1;
			var b=req.body.d2;
            var c=req.body.d3;
			var d=req.body.d4;
            var e=req.body.d5;
			var f=req.body.d6;
            var g=req.body.d7;
			var h=req.body.d8;
            var i=req.body.d9;
			var j=req.body.d10;
            var k=req.body.d11;
			var l=req.body.d12;
            var m=req.body.d13;
		
    var con=mysql.createConnection({host:"localhost",user:"root",password:"root",database:"pharmacyproject"});
con.connect(function(err)
{
if(err) throw err;
console.log("connected");
con.query(" update  doctorregistration set doc_name='"+b+"',doc_fthrname='"+c+"',moblno='"+d+"',dob='"+e+"',bloodgrp='"+f+"',email='"+g+"',website='"+h+"',address='"+i+"',speciality='"+j+"',department='"+k+"',qualification='"+l+"',academic='"+m+"' where doc_Id='"+a+"'",function(err,result)
{
if(err) throw err;
console.log("Database created");

});
});
//data base code end
            res.send("<div align ='center'><h2>Registration successful</h2></div><br><br><div align='center'><a href='./login.html'>login</a></div><br><br><div align='center'><a href='./registration.html'>Register another user</a></div>");
        } else {
            res.send("<div align ='center'><h2>Email already used</h2></div><br><br><div align='center'><a href='./PatientRegistrationForm.html'>Enter Again</a></div>");
        }
    } catch{
        res.send("Internal server error");
    }
});
















app.post('/medicinedetailsdata', async (req, res) => {
    try{
        let foundUser = users.find((data) => req.body.d1 === data.email);
        if (!foundUser) {
    
            let hashPassword = await bcrypt.hash(req.body.d1, 10);
    
            let newUser = {
                id: Date.now(),
                username: req.body.d1,
                email: req.body.d2,
                password: hashPassword,
            };
            users.push(newUser);
            console.log('User list', users);
			//Data bse code start
			var a=req.body.d1;
			var b=req.body.d2;
            var c=req.body.d3;
			var d=req.body.d4;
            var e=req.body.d5;
			var f=req.body.d6;
            var g=req.body.d7;
          
    var con=mysql.createConnection({host:"localhost",user:"root",password:"root",database:"pharmacyproject"});
con.connect(function(err)
{
if(err) throw err;
console.log("connected");
con.query(" insert into medicineformrecord(med_category,med_name,med_dose,med_ingredients,company_name,company_contact,tenasaction_id) values('"+a+"','"+b+"','"+c+"','"+d+"','"+e+"','"+f+"','"+g+"')",function(err,result)
{
if(err) throw err;
console.log("Database created");

});
});
//data base code end
            res.send("<div align ='center'><h2>Registration successful</h2></div><br><br><div align='center'><a href='./login.html'>login</a></div><br><br><div align='center'><a href='./registration.html'>Register another user</a></div>");
        } else {
            res.send("<div align ='center'><h2>Email already used</h2></div><br><br><div align='center'><a href='./PatientRegistrationForm.html'>Enter Again</a></div>");
        }
    } catch{
        res.send("Internal server error");
    }
});


app.post('/medicinedetailsdataupdate', async (req, res) => {
    try{
        let foundUser = users.find((data) => req.body.d1 === data.email);
        if (!foundUser) {
    
            let hashPassword = await bcrypt.hash(req.body.d1, 10);
    
            let newUser = {
                id: Date.now(),
                username: req.body.d1,
                email: req.body.d2,
                password: hashPassword,
            };
            users.push(newUser);
            console.log('User list', users);
			//Data bse code start
			var a=req.body.d1;
			var b=req.body.d2;
            var c=req.body.d3;
			var d=req.body.d4;
            var e=req.body.d5;
			var f=req.body.d6;
            var g=req.body.d7;
          
    var con=mysql.createConnection({host:"localhost",user:"root",password:"root",database:"pharmacyproject"});
con.connect(function(err)
{
if(err) throw err;
console.log("connected");
con.query("update  medicineformrecord set med_category='"+a+"',med_name='"+b+"',med_dose='"+c+"',med_ingredients='"+d+"',company_name='"+e+"',company_contact='"+f+"' where tenasaction_id='"+g+"'",function(err,result)
{
if(err) throw err;
console.log("Database created");

});
});
//data base code end
            res.send("<div align ='center'><h2>Registration successful</h2></div><br><br><div align='center'><a href='./login.html'>login</a></div><br><br><div align='center'><a href='./registration.html'>Register another user</a></div>");
        } else {
            res.send("<div align ='center'><h2>Email already used</h2></div><br><br><div align='center'><a href='./PatientRegistrationForm.html'>Enter Again</a></div>");
        }
    } catch{
        res.send("Internal server error");
    }
});




/*****************************LOGIN APIS*/
/* DISPLAYING DATA MODULE*/ 

app.post('/doctorregistrationdatadisplay', async (req, res) => {
    try{
      
		
    var con=mysql.createConnection({host:"localhost",user:"root",password:"root",database:"pharmacyproject"});
con.connect(function(err)
{
if(err) throw err;
console.log("connected");
con.query(" select * from doctorregistration",function(err,result)
{
if(err) throw err;
console.log("Database created");
res.send("<div  style='height: 600px; width: 100%;background-color:#72777c; margin: auto;'><div  style='height: 598px;  width: 80%;border: 1px solid blue;background-color: #b3b6ba;color: black;margin: auto;'><div class='HELLO'>       <div  style='margin-top: 10px;font-size: 18px; display: flex; align-items: center;justify-content: space-evenly;'><div  style='margin-top: 20px; gap: 10px;display: flex;'><div  style='    width: 170px; height: 35px;border: 1px solid blue; display: flex; align-items: center; border-radius: 5px;'>Doctor ID: </div><div style=' height: 35px; width: 250px; border: 1px solid red;border-radius: 5px;display:flex;align-items:center;justify-content:center;'>"+result[0].doc_Id+"</div></div><div  style='margin-top: 20px; gap: 10px;display: flex;'><div  style='  width: 170px; height: 35px; border: 1px solid blue;   display: flex;  align-items: center; border-radius: 5px;'>Contact Number :</div><div style=' height: 35px; width: 250px; border: 1px solid red;border-radius: 5px; display:flex;align-items:center;justify-content:center;'> "+result[0].doc_cont+"</div></div></div>     <div  style='margin-top: 10px;font-size: 18px; display: flex; align-items: center;justify-content: space-evenly;'><div  style='margin-top: 20px; gap: 10px;display: flex;'><div  style='    width: 170px; height: 35px;border: 1px solid blue; display: flex; align-items: center; border-radius: 5px;'>Doctor Name: </div><div style=' height: 35px; width: 250px; border: 1px solid red;border-radius: 5px;display:flex;align-items:center;justify-content:center;'>"+result[0].doc_name+"</div></div><div  style='margin-top: 20px; gap: 10px;display: flex;'><div  style='  width: 170px; height: 35px; border: 1px solid blue;   display: flex;  align-items: center; border-radius: 5px;'>doctor's Father Name :</div><div style=' height: 35px; width: 250px; border: 1px solid red;border-radius: 5px; display:flex;align-items:center;justify-content:center;'> "+result[0].doc_fthrname+"</div></div></div>           <div  style='margin-top: 10px;font-size: 18px; display: flex; align-items: center;justify-content: space-evenly;'><div  style='margin-top: 20px; gap: 10px;display: flex;'><div  style='    width: 170px; height: 35px;border: 1px solid blue; display: flex; align-items: center; border-radius: 5px;'>DOB: </div><div style=' height: 35px; width: 250px; border: 1px solid red;border-radius: 5px;display:flex;align-items:center;justify-content:center;'>"+result[0].dob+"</div></div><div  style='margin-top: 20px; gap: 10px;display: flex;'><div  style='  width: 170px; height: 35px; border: 1px solid blue;   display: flex;  align-items: center; border-radius: 5px;'>Blood Group :</div><div style=' height: 35px; width: 250px; border: 1px solid red;border-radius: 5px; display:flex;align-items:center;justify-content:center;'> "+result[0].bloodgrp+"</div></div></div>           <div  style='margin-top: 10px;font-size: 18px; display: flex; align-items: center;justify-content: space-evenly;'><div  style='margin-top: 20px; gap: 10px;display: flex;'><div  style='    width: 170px; height: 35px;border: 1px solid blue; display: flex; align-items: center; border-radius: 5px;'>Email: </div><div style=' height: 35px; width: 250px; border: 1px solid red;border-radius: 5px;display:flex;align-items:center;justify-content:center;'>"+result[0].email+"</div></div><div  style='margin-top: 20px; gap: 10px;display: flex;'><div  style='  width: 170px; height: 35px; border: 1px solid blue;   display: flex;  align-items: center; border-radius: 5px;'>Website :</div><div style=' height: 35px; width: 250px; border: 1px solid red;border-radius: 5px; display:flex;align-items:center;justify-content:center;'> "+result[0].website+"</div></div></div>           <div  style='margin-top: 10px;font-size: 18px; display: flex; align-items: center;justify-content: space-evenly;'><div  style='margin-top: 20px; gap: 10px;display: flex;'><div  style='    width: 170px; height: 35px;border: 1px solid blue; display: flex; align-items: center; border-radius: 5px;'>Address: </div><div style=' height: 35px; width: 250px; border: 1px solid red;border-radius: 5px;display:flex;align-items:center;justify-content:center;'>"+result[0].address+"</div></div><div  style='margin-top: 20px; gap: 10px;display: flex;'><div  style='  width: 170px; height: 35px; border: 1px solid blue;   display: flex;  align-items: center; border-radius: 5px;'>Speciality:</div><div style=' height: 35px; width: 250px; border: 1px solid red;border-radius: 5px; display:flex;align-items:center;justify-content:center;'> "+result[0].speciality+"</div></div></div>           <div  style='margin-top: 10px;font-size: 18px; display: flex; align-items: center;justify-content: space-evenly;'><div  style='margin-top: 20px; gap: 10px;display: flex;'><div  style='    width: 170px; height: 35px;border: 1px solid blue; display: flex; align-items: center; border-radius: 5px;'>Department: </div><div style=' height: 35px; width: 250px; border: 1px solid red;border-radius: 5px;display:flex;align-items:center;justify-content:center;'>"+result[0].department+"</div></div><div  style='margin-top: 20px; gap: 10px;display: flex;'><div  style='  width: 170px; height: 35px; border: 1px solid blue;   display: flex;  align-items: center; border-radius: 5px;'>Qualification :</div><div style=' height: 35px; width: 250px; border: 1px solid red;border-radius: 5px; display:flex;align-items:center;justify-content:center;'> "+result[0].qualification+"</div></div></div>  <div  style='margin-top: 10px;font-size: 18px; display: flex; align-items: center;justify-content: space-evenly;'><div  style='margin-top: 20px; gap: 10px;display: flex;'><div  style='    width: 170px; height: 35px;border: 1px solid blue; display: flex; align-items: center; border-radius: 5px;'>Address: </div><div style=' height: 35px; width: 250px; border: 1px solid red;border-radius: 5px;display:flex;align-items:center;justify-content:center;'>"+result[0].address+"</div></div><div  style='margin-top: 20px; gap: 10px;display: flex;'><div  style='  width: 170px; height: 35px;   display: flex;  align-items: center; border-radius: 5px;'></div><div style=' height: 35px; width: 250px;border-radius: 5px; display:flex;align-items:center;justify-content:center;'></div></div></div>           </div></div></div> ");

// </div>")




// res.send("<div align ='center'> <h3>Doctor ID : "+result[0].doc_Id+"</h3> <h3>Doctor Name : "+result[0].doc_name+"</h3><h3>Doctor Father Name: "+result[0].doc_fthrname+"</h3> <h3>Contact number "+result[0].moblno+"</h3><h3>DOB: "+result[0].dob+"</h3> <h3>Blood Group : "+result[0].bloodgrp+"</h3><h3>Email : "+result[0].email+"</h3> <h3>Website : "+result[0].website+"</h3><h3>Address : "+result[0].address+"</h3> <h3>Speciality : "+result[0].speciality+"</h3><h3>Department : "+result[0].department+"</h3> <h3>Qualification : "+result[0].qualification+"</h3><h3>Academic : "+result[0].academic+"</h3> </div>        ");
// res.send("<div align ='center'> "+result[0].doc_name+"</div>");

});
});
//data base code end
            
       
    } catch{
        res.send("Internal server error");
    }
});





app.post('/patientregistrationdatadisplay', async (req, res) => {
    try{
      
		
    var con=mysql.createConnection({host:"localhost",user:"root",password:"root",database:"pharmacyproject"});
con.connect(function(err)
{
if(err) throw err;
console.log("connected");
con.query(" select * from patientregistration",function(err,result)
{
if(err) throw err;
console.log("Database created");
res.send("<div  style='height: 600px; width: 100%;background-color:#72777c; margin: auto;'><div  style='height: 598px;  width: 80%;border: 1px solid blue;background-color: #b3b6ba;color: black;margin: auto;'><div class='HELLO'>       <div  style='margin-top: 10px;font-size: 18px; display: flex; align-items: center;justify-content: space-evenly;'><div  style='margin-top: 20px; gap: 10px;display: flex;'><div  style='    width: 170px; height: 35px;border: 1px solid blue; display: flex; align-items: center; border-radius: 5px;'>Patient Name : </div><div style=' height: 35px; width: 250px; border: 1px solid red;border-radius: 5px;display:flex;align-items:center;justify-content:center;'>"+result[0].patient_name+"</div></div><div  style='margin-top: 20px; gap: 10px;display: flex;'><div  style='  width: 170px; height: 35px; border: 1px solid blue;   display: flex;  align-items: center; border-radius: 5px;'>Father Name :</div><div style=' height: 35px; width: 250px; border: 1px solid red;border-radius: 5px; display:flex;align-items:center;justify-content:center;'> "+result[0].father_name+"</div></div></div>     <div  style='margin-top: 10px;font-size: 18px; display: flex; align-items: center;justify-content: space-evenly;'><div  style='margin-top: 20px; gap: 10px;display: flex;'><div  style='    width: 170px; height: 35px;border: 1px solid blue; display: flex; align-items: center; border-radius: 5px;'>Gender: </div><div style=' height: 35px; width: 250px; border: 1px solid red;border-radius: 5px;display:flex;align-items:center;justify-content:center;'>"+result[0].gender+"</div></div><div  style='margin-top: 20px; gap: 10px;display: flex;'><div  style='  width: 170px; height: 35px; border: 1px solid blue;   display: flex;  align-items: center; border-radius: 5px;'>Contact Number :</div><div style=' height: 35px; width: 250px; border: 1px solid red;border-radius: 5px; display:flex;align-items:center;justify-content:center;'> "+result[0].mobileno+"</div></div></div>           <div  style='margin-top: 10px;font-size: 18px; display: flex; align-items: center;justify-content: space-evenly;'><div  style='margin-top: 20px; gap: 10px;display: flex;'><div  style='    width: 170px; height: 35px;border: 1px solid blue; display: flex; align-items: center; border-radius: 5px;'>DOB: </div><div style=' height: 35px; width: 250px; border: 1px solid red;border-radius: 5px;display:flex;align-items:center;justify-content:center;'>"+result[0].DOB+"</div></div><div  style='margin-top: 20px; gap: 10px;display: flex;'><div  style='  width: 170px; height: 35px; border: 1px solid blue;   display: flex;  align-items: center; border-radius: 5px;'>Blood Group :</div><div style=' height: 35px; width: 250px; border: 1px solid red;border-radius: 5px; display:flex;align-items:center;justify-content:center;'> "+result[0].bloodgrp+"</div></div></div>           <div  style='margin-top: 10px;font-size: 18px; display: flex; align-items: center;justify-content: space-evenly;'><div  style='margin-top: 20px; gap: 10px;display: flex;'><div  style='    width: 170px; height: 35px;border: 1px solid blue; display: flex; align-items: center; border-radius: 5px;'>Marital Status: </div><div style=' height: 35px; width: 250px; border: 1px solid red;border-radius: 5px;display:flex;align-items:center;justify-content:center;'>"+result[0].marital_status+"</div></div><div  style='margin-top: 20px; gap: 10px;display: flex;'><div  style='  width: 170px; height: 35px; border: 1px solid blue;   display: flex;  align-items: center; border-radius: 5px;'>Patient's Address:</div><div style=' height: 35px; width: 250px; border: 1px solid red;border-radius: 5px; display:flex;align-items:center;justify-content:center;'> "+result[0].patient_address+"</div></div></div>           <div  style='margin-top: 10px;font-size: 18px; display: flex; align-items: center;justify-content: space-evenly;'><div  style='margin-top: 20px; gap: 10px;display: flex;'><div  style='    width: 170px; height: 35px;border: 1px solid blue; display: flex; align-items: center; border-radius: 5px;'>Email: </div><div style=' height: 35px; width: 250px; border: 1px solid red;border-radius: 5px;display:flex;align-items:center;justify-content:center;'>"+result[0].Email+"</div></div><div  style='margin-top: 20px; gap: 10px;display: flex;'><div  style='  width: 170px; height: 35px; border: 1px solid blue;   display: flex;  align-items: center; border-radius: 5px;'>Transaction Id:</div><div style=' height: 35px; width: 250px; border: 1px solid red;border-radius: 5px; display:flex;align-items:center;justify-content:center;'> "+result[0].transaction_id+"</div></div></div>                        </div></div></div> ");s.send("<div align ='center'> "+result[0].doc_name+"</div>");

});
});
//data base code end
            
       
    } catch{
        res.send("Internal server error");
    }
});



app.post('/medicinedetailsdatadisplay', async (req, res) => {
    try{
      
		
    var con=mysql.createConnection({host:"localhost",user:"root",password:"root",database:"pharmacyproject"});
con.connect(function(err)
{
if(err) throw err;
console.log("connected");
con.query(" select * from medicineformrecord",function(err,result)
{
if(err) throw err;
console.log("Database created");
res.send("<div  style='height: 600px; width: 100%;background-color:#72777c; margin: auto;'><div  style='height: 598px;  width: 80%;border: 1px solid blue;background-color: #b3b6ba;color: black;margin: auto;'><div class='HELLO'>       <div  style='margin-top: 10px;font-size: 18px; display: flex; align-items: center;justify-content: space-evenly;'><div  style='margin-top: 20px; gap: 10px;display: flex;'><div  style='    width: 170px; height: 35px;border: 1px solid blue; display: flex; align-items: center; border-radius: 5px;'>Medicine Category: </div><div style=' height: 35px; width: 250px; border: 1px solid red;border-radius: 5px;display:flex;align-items:center;justify-content:center;'>"+result[0].med_category+"</div></div><div  style='margin-top: 20px; gap: 10px;display: flex;'><div  style='  width: 170px; height: 35px; border: 1px solid blue;   display: flex;  align-items: center; border-radius: 5px;'>Medicine Name :</div><div style=' height: 35px; width: 250px; border: 1px solid red;border-radius: 5px; display:flex;align-items:center;justify-content:center;'> "+result[0].med_name+"</div></div></div>     <div  style='margin-top: 10px;font-size: 18px; display: flex; align-items: center;justify-content: space-evenly;'><div  style='margin-top: 20px; gap: 10px;display: flex;'><div  style='    width: 170px; height: 35px;border: 1px solid blue; display: flex; align-items: center; border-radius: 5px;'>Medicine Dose: </div><div style=' height: 35px; width: 250px; border: 1px solid red;border-radius: 5px;display:flex;align-items:center;justify-content:center;'>"+result[0].med_dose+"</div></div><div  style='margin-top: 20px; gap: 10px;display: flex;'><div  style='  width: 170px; height: 35px; border: 1px solid blue;   display: flex;  align-items: center; border-radius: 5px;'>Medicine Ingredients :</div><div style=' height: 35px; width: 250px; border: 1px solid red;border-radius: 5px; display:flex;align-items:center;justify-content:center;'> "+result[0].med_ingredients+"</div></div></div>           <div  style='margin-top: 10px;font-size: 18px; display: flex; align-items: center;justify-content: space-evenly;'><div  style='margin-top: 20px; gap: 10px;display: flex;'><div  style='    width: 170px; height: 35px;border: 1px solid blue; display: flex; align-items: center; border-radius: 5px;'>Company Name: </div><div style=' height: 35px; width: 250px; border: 1px solid red;border-radius: 5px;display:flex;align-items:center;justify-content:center;'>"+result[0].company_name+"</div></div><div  style='margin-top: 20px; gap: 10px;display: flex;'><div  style='  width: 170px; height: 35px; border: 1px solid blue;   display: flex;  align-items: center; border-radius: 5px;'>Company Contact Number :</div><div style=' height: 35px; width: 250px; border: 1px solid red;border-radius: 5px; display:flex;align-items:center;justify-content:center;'> "+result[0].company_contact+"</div></div></div>           <div  style='margin-top: 10px;font-size: 18px; display: flex; align-items: center;justify-content: space-evenly;'><div  style='margin-top: 20px; gap: 10px;display: flex;'><div  style='    width: 170px; height: 35px;border: 1px solid blue; display: flex; align-items: center; border-radius: 5px;'>Medicine Code: </div><div style=' height: 35px; width: 250px; border: 1px solid red;border-radius: 5px;display:flex;align-items:center;justify-content:center;'>"+result[0].tenasaction_id+"</div></div><div  style='margin-top: 20px; gap: 10px;display: flex;'><div  style='  width: 170px; height: 35px;   display: flex;  align-items: center; border-radius: 5px;'></div><div style=' height: 35px; width: 250px;;border-radius: 5px; display:flex;align-items:center;justify-content:center;'></div></div></div>                  </div></div></div> ");

});
});
//data base code end
            
       
    } catch{
        res.send("Internal server error");
    }
});

















server.listen(3000, function(){
    console.log("server is listening on port: 3000");
});